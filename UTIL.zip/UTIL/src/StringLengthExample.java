public class StringLengthExample {
    public static void main(String[] args) {
        String str = "Hello World";
        System.out.println("문자열 길이: " + str.length()); // 출력: 11
        
        String empty = "";
        System.out.println("빈 문자열 길이: " + empty.length()); // 출력: 0
    }
}